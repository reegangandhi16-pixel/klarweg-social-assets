# C2 — Sofern vs insofern, als: condition and scope

Intended date/time: **2026-11-18 20:00 IST**. Prepared content only; publishing is not enabled.

Facebook and Threads: use [01.jpg](01.jpg) with their respective caption/text files.

Instagram: use [01.jpg](01.jpg), [02.jpg](02.jpg), [03.jpg](03.jpg), [04.jpg](04.jpg) in order. Music can be added in the app after publishing. These files are not native Instagram drafts.
